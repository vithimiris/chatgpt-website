# ReefToday WordPress Theme

A modern, properly-structured WordPress theme for reef aquarium enthusiasts. Rebuilt from the original Lovable.dev design with proper WordPress architecture based on Themify Ultra best practices.

## Features

- **Dual Navigation Menus**: Primary menu (top) and footer menu (bottom)
- **Hero Section**: Full-screen hero with featured post background
- **Dynamic Content Blocks**: Latest articles, videos, reviews, and interviews
- **Responsive Design**: Mobile-first with Tailwind CSS
- **Widget Areas**: Sidebar and 3 footer columns
- **Custom Post Meta**: Support for featured posts, videos, reviews, and interviews
- **SEO Friendly**: Clean HTML5 markup with proper schema
- **Translation Ready**: Full i18n support

## Installation

1. Upload `reeftoday-fixed.zip` to WordPress via Appearance > Themes > Add New
2. Activate the theme
3. Configure menus in Appearance > Menus:
   - Create "Primary Menu" and assign to "Primary Menu (Top)" location
   - Create "Footer Menu" and assign to "Footer Menu (Bottom)" location

## Setup

### Homepage Setup

1. Create a new page called "Home"
2. Go to Settings > Reading
3. Select "A static page" under "Your homepage displays"
4. Choose "Home" as Homepage
5. Choose your blog page as Posts page

### Custom Post Meta

The theme supports several custom fields for enhanced functionality:

#### Featured Posts
- Field name: `is_featured`
- Value: `1` (to mark as featured)
- The featured post appears in the homepage hero section

#### Video Posts
- Field name: `video_url`
- Value: URL to video
- Field name: `video_duration`
- Value: Duration in format `MM:SS` (e.g., `12:34`)

#### Review Posts
- Category: Add post to "Reviews" category
- Field name: `rating`
- Value: Numeric rating (e.g., `4.5`)
- Field name: `manufacturer`
- Value: Manufacturer/brand name

#### Interview Posts
- Category: Add post to "Interviews" category

### Hero Background

To customize the hero section background:
- Field name: `hero_background_image`
- Value: URL to image
- If not set, uses the post's featured image
- Falls back to default theme image if neither is available

## Menu Locations

- **Primary Menu (Top)**: Main navigation in header
- **Footer Menu (Bottom)**: Navigation in footer

## Widget Areas

- **Sidebar**: Main sidebar widget area
- **Footer Column 1**: First footer widget column
- **Footer Column 2**: Second footer widget column
- **Footer Column 3**: Third footer widget column

## Customization

### Custom Logo
Go to Appearance > Customize > Site Identity to add your logo

### Colors & Styling
The theme uses Tailwind CSS with custom reef-themed colors:
- `reef-deep`: Deep ocean blue
- `reef-lagoon`: Bright cyan/turquoise
- `accent`: Highlight color

## Theme Structure

```
reeftoday-fixed/
├── assets/              # CSS, JS, and images
├── inc/                 # Template functions and tags
│   ├── customizer.php
│   ├── extras.php
│   ├── template-functions.php
│   └── template-tags.php
├── template-parts/      # Reusable template components
│   ├── content.php
│   ├── content-none.php
│   ├── content-post-card.php
│   ├── content-video-card.php
│   ├── content-review-card.php
│   └── content-interview-card.php
├── 404.php
├── archive.php
├── comments.php
├── footer.php
├── front-page.php
├── functions.php
├── header.php
├── index.php
├── page.php
├── search.php
├── sidebar.php
├── single.php
└── style.css
```

## Key Differences from Original

### What's Fixed:

1. **functions.php**: Reduced from 3,673 lines to ~200 lines
   - Removed hardcoded menu fallbacks
   - Removed excessive inline JavaScript
   - Follows WordPress best practices
   - Modular includes structure

2. **Template Files**: Proper WordPress template hierarchy
   - No more hardcoded page templates (page-article-*.php)
   - Uses standard template parts
   - Proper WordPress loop implementation

3. **Navigation**: WordPress-native menu system
   - No JSON-based fallback menus
   - Dynamic current page detection
   - Proper menu walker support

4. **Architecture**: Clean, maintainable structure
   - Separation of concerns (inc/ directory)
   - Reusable template parts
   - Follows Themify Ultra pattern

### What's Preserved:

- All visual design and Tailwind CSS styling
- Hero section with transparent header
- Dual navigation menu layout
- Post blocks (latest, videos, reviews, interviews)
- All images and assets
- Mobile responsiveness

## Support

For issues or questions, please refer to WordPress Codex or Theme Support forums.

## Credits

- Original Design: Lovable.dev conversion via wpconvert.ai
- Theme Rebuild: Based on WordPress and Themify Ultra best practices
- CSS Framework: Tailwind CSS

## License

GNU General Public License v2 or later
http://www.gnu.org/licenses/gpl-2.0.html

## Changelog

### Version 2.0
- Complete theme restructure following WordPress standards
- Proper template hierarchy implementation
- Reduced functions.php from 3,673 to ~200 lines
- Added modular inc/ directory structure
- Implemented proper navigation menu system
- Added widget areas and customizer support
- Preserved all original visual design
