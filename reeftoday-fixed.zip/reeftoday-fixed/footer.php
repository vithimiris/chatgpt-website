    </div><!-- #content -->

    <footer id="colophon" class="site-footer bg-reef-deep text-primary-foreground py-12">
        <div class="container mx-auto px-4">
            <?php if (is_active_sidebar('footer-1') || is_active_sidebar('footer-2') || is_active_sidebar('footer-3')) : ?>
                <div class="footer-widgets grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
                    <div class="footer-widget-area">
                        <?php dynamic_sidebar('footer-1'); ?>
                    </div>
                    <div class="footer-widget-area">
                        <?php dynamic_sidebar('footer-2'); ?>
                    </div>
                    <div class="footer-widget-area">
                        <?php dynamic_sidebar('footer-3'); ?>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Footer Menu (Bottom) -->
            <?php if (has_nav_menu('footer')) : ?>
                <nav class="footer-navigation border-t border-primary-foreground/20 pt-8 mb-6" role="navigation">
                    <?php
                    wp_nav_menu(array(
                        'theme_location' => 'footer',
                        'menu_id'        => 'footer-menu',
                        'container'      => false,
                        'menu_class'     => 'flex flex-wrap justify-center gap-6 text-sm',
                        'fallback_cb'    => '__return_false',
                        'depth'          => 1,
                    ));
                    ?>
                </nav>
            <?php endif; ?>

            <div class="site-info text-center text-sm text-primary-foreground/70">
                <?php
                printf(
                    /* translators: 1: Theme name, 2: Theme author */
                    esc_html__('&copy; %1$s %2$s. All rights reserved.', 'reeftoday'),
                    date('Y'),
                    get_bloginfo('name')
                );
                ?>
            </div>
        </div>
    </footer>
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
