<?php
/**
 * The template for displaying 404 pages (not found)
 */

get_header();
?>

<div id="primary" class="content-area container mx-auto px-4 py-12">
    <main id="main" class="site-main">

        <section class="error-404 not-found text-center py-24">
            <header class="page-header mb-8">
                <h1 class="page-title font-display text-6xl md:text-8xl font-bold mb-4">404</h1>
                <p class="text-xl text-muted-foreground"><?php esc_html_e('Oops! That page can&rsquo;t be found.', 'reeftoday'); ?></p>
            </header>

            <div class="page-content max-w-2xl mx-auto">
                <p class="mb-8"><?php esc_html_e('It looks like nothing was found at this location. Maybe try searching?', 'reeftoday'); ?></p>

                <?php get_search_form(); ?>
            </div>
        </section>

    </main>
</div>

<?php
get_footer();
