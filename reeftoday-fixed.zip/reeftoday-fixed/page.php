<?php
/**
 * The template for displaying pages
 */

get_header();
?>

<div id="primary" class="content-area">
    <main id="main" class="site-main">

        <?php
        while (have_posts()) :
            the_post();
            ?>
            
            <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                <div class="container mx-auto px-4 py-12">
                    <div class="max-w-4xl mx-auto">
                        
                        <header class="entry-header mb-8">
                            <?php the_title('<h1 class="entry-title font-display text-4xl md:text-5xl font-bold">', '</h1>'); ?>
                        </header>

                        <?php if (has_post_thumbnail()) : ?>
                            <div class="post-thumbnail mb-8 rounded-2xl overflow-hidden">
                                <?php the_post_thumbnail('reeftoday-hero', array('class' => 'w-full h-auto')); ?>
                            </div>
                        <?php endif; ?>

                        <div class="entry-content prose prose-lg max-w-none">
                            <?php
                            the_content();

                            wp_link_pages(array(
                                'before' => '<div class="page-links">' . esc_html__('Pages:', 'reeftoday'),
                                'after'  => '</div>',
                            ));
                            ?>
                        </div>

                    </div>
                </div>
            </article>

            <?php
            // If comments are open or we have at least one comment, load up the comment template.
            if (comments_open() || get_comments_number()) :
                comments_template();
            endif;

        endwhile; // End of the loop.
        ?>

    </main>
</div>

<?php
get_footer();
