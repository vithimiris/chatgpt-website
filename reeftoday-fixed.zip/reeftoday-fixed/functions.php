<?php
/**
 * ReefToday Theme Functions
 * 
 * Properly structured following WordPress and Themify Ultra best practices
 * 
 * @package ReefToday
 * @version 2.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Theme Setup
 */
function reeftoday_setup() {
    // Make theme available for translation
    load_theme_textdomain('reeftoday', get_template_directory() . '/languages');
    
    // Add default posts and comments RSS feed links to head
    add_theme_support('automatic-feed-links');
    
    // Let WordPress manage the document title
    add_theme_support('title-tag');
    
    // Enable support for Post Thumbnails
    add_theme_support('post-thumbnails');
    
    // Set post thumbnail size
    set_post_thumbnail_size(1200, 675, true);
    
    // Additional image sizes
    add_image_size('reeftoday-hero', 1920, 1080, true);
    add_image_size('reeftoday-large', 800, 600, true);
    add_image_size('reeftoday-medium', 400, 300, true);
    
    // Register navigation menus
    register_nav_menus(array(
        'primary' => __('Primary Menu (Top)', 'reeftoday'),
        'footer'  => __('Footer Menu (Bottom)', 'reeftoday'),
    ));
    
    // Switch default core markup to output valid HTML5
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script',
    ));
    
    // Add theme support for custom logo
    add_theme_support('custom-logo', array(
        'height'      => 100,
        'width'       => 400,
        'flex-height' => true,
        'flex-width'  => true,
    ));
    
    // Add support for responsive embeds
    add_theme_support('responsive-embeds');
    
    // Add support for editor styles
    add_theme_support('editor-styles');
}
add_action('after_setup_theme', 'reeftoday_setup');

/**
 * Set content width
 */
function reeftoday_content_width() {
    $GLOBALS['content_width'] = apply_filters('reeftoday_content_width', 1200);
}
add_action('after_setup_theme', 'reeftoday_content_width', 0);

/**
 * Register widget areas
 */
function reeftoday_widgets_init() {
    register_sidebar(array(
        'name'          => __('Sidebar', 'reeftoday'),
        'id'            => 'sidebar-1',
        'description'   => __('Add widgets here to appear in your sidebar.', 'reeftoday'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ));
    
    register_sidebar(array(
        'name'          => __('Footer Column 1', 'reeftoday'),
        'id'            => 'footer-1',
        'description'   => __('Appears in the footer area', 'reeftoday'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));
    
    register_sidebar(array(
        'name'          => __('Footer Column 2', 'reeftoday'),
        'id'            => 'footer-2',
        'description'   => __('Appears in the footer area', 'reeftoday'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));
    
    register_sidebar(array(
        'name'          => __('Footer Column 3', 'reeftoday'),
        'id'            => 'footer-3',
        'description'   => __('Appears in the footer area', 'reeftoday'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));
}
add_action('widgets_init', 'reeftoday_widgets_init');

/**
 * Enqueue scripts and styles
 */
function reeftoday_scripts() {
    // Enqueue main stylesheet from assets
    wp_enqueue_style('reeftoday-tailwind', get_template_directory_uri() . '/assets/css/index-CSNW_gH9.css', array(), '2.0');
    
    // Enqueue theme style
    wp_enqueue_style('reeftoday-style', get_stylesheet_uri(), array('reeftoday-tailwind'), '2.0');
    
    // Enqueue navigation script
    wp_enqueue_script('reeftoday-navigation', get_template_directory_uri() . '/assets/js/navigation.js', array(), '2.0', true);
    
    // Enqueue comment reply script
    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}
add_action('wp_enqueue_scripts', 'reeftoday_scripts');

/**
 * Helper function to get featured post
 */
function reeftoday_get_featured_post() {
    $args = array(
        'posts_per_page' => 1,
        'post_status'    => 'publish',
        'meta_query'     => array(
            array(
                'key'     => 'is_featured',
                'value'   => '1',
                'compare' => '='
            )
        )
    );
    
    $query = new WP_Query($args);
    
    // If no featured post found, get the latest post
    if (!$query->have_posts()) {
        $args = array(
            'posts_per_page' => 1,
            'post_status'    => 'publish',
            'orderby'        => 'date',
            'order'          => 'DESC'
        );
        $query = new WP_Query($args);
    }
    
    return $query;
}

/**
 * Helper function to get latest posts
 */
function reeftoday_get_latest_posts($number = 4, $offset = 1) {
    $args = array(
        'posts_per_page' => $number,
        'post_status'    => 'publish',
        'orderby'        => 'date',
        'order'          => 'DESC',
        'offset'         => $offset
    );
    
    return new WP_Query($args);
}

/**
 * Helper function to get video posts
 */
function reeftoday_get_video_posts($number = 4) {
    $args = array(
        'posts_per_page' => $number,
        'post_status'    => 'publish',
        'meta_query'     => array(
            array(
                'key'     => 'video_url',
                'compare' => 'EXISTS'
            )
        )
    );
    
    return new WP_Query($args);
}

/**
 * Helper function to get review posts
 */
function reeftoday_get_review_posts($number = 4) {
    $args = array(
        'posts_per_page' => $number,
        'post_status'    => 'publish',
        'category_name'  => 'reviews'
    );
    
    return new WP_Query($args);
}

/**
 * Helper function to get interview posts
 */
function reeftoday_get_interview_posts($number = 2) {
    $args = array(
        'posts_per_page' => $number,
        'post_status'    => 'publish',
        'category_name'  => 'interviews'
    );
    
    return new WP_Query($args);
}

/**
 * Load theme includes (following Themify Ultra pattern)
 */
$theme_includes = array(
    'inc/template-tags.php',      // Custom template tags
    'inc/template-functions.php', // Template functions
    'inc/customizer.php',         // Customizer additions
    'inc/extras.php',             // Additional helper functions
);

foreach ($theme_includes as $include) {
    $include_path = get_template_directory() . '/' . $include;
    if (file_exists($include_path)) {
        require_once $include_path;
    }
}
