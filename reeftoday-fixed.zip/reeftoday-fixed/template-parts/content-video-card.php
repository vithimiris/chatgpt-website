<?php
/**
 * Template part for displaying video cards
 */

$video_duration = get_post_meta(get_the_ID(), 'video_duration', true);
if (empty($video_duration)) $video_duration = '00:00';
?>

<article class="group cursor-pointer overflow-hidden rounded-2xl bg-card shadow-sm transition-all hover:shadow-xl">
    <div class="relative aspect-video overflow-hidden">
        <?php if (has_post_thumbnail()) : ?>
            <?php the_post_thumbnail('reeftoday-medium', array('class' => 'h-full w-full object-cover transition-transform duration-500 group-hover:scale-105')); ?>
        <?php else : ?>
            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/reef-tank-DkvgXldr.jpg" alt="<?php the_title_attribute(); ?>" class="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105">
        <?php endif; ?>
        
        <div class="absolute inset-0 flex items-center justify-center bg-reef-deep/30 opacity-0 transition-opacity group-hover:opacity-100">
            <div class="flex h-16 w-16 items-center justify-center rounded-full bg-accent shadow-lg">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-play h-6 w-6 text-accent-foreground">
                    <polygon points="6 3 20 12 6 21 6 3"></polygon>
                </svg>
            </div>
        </div>
        
        <div class="absolute bottom-3 right-3 flex items-center gap-1.5 rounded-full bg-reef-deep/80 px-3 py-1 backdrop-blur-sm">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-clock h-3.5 w-3.5 text-primary-foreground/80">
                <circle cx="12" cy="12" r="10"></circle>
                <polyline points="12 6 12 12 16 14"></polyline>
            </svg>
            <span class="text-xs font-medium text-primary-foreground"><?php echo esc_html($video_duration); ?></span>
        </div>
    </div>
    
    <div class="p-5">
        <?php 
        $categories = get_the_category();
        if (!empty($categories)) :
        ?>
            <span class="text-xs font-semibold uppercase tracking-wide text-accent">
                <?php echo esc_html($categories[0]->name); ?>
            </span>
        <?php endif; ?>
        
        <h3 class="mt-2 font-display text-lg font-semibold leading-snug text-card-foreground transition-colors group-hover:text-primary">
            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
        </h3>
    </div>
</article>
