<?php
/**
 * Template part for displaying post cards
 */

$index = isset($args['index']) ? $args['index'] : 0;
$is_large = ($index == 0);
$thumbnail_class = $is_large ? 'aspect-[4/3] overflow-hidden lg:aspect-auto lg:h-full' : 'h-24 w-24 flex-shrink-0 overflow-hidden rounded-lg md:h-28 md:w-28';
?>

<?php if ($is_large) : ?>
    <!-- Large Featured Card -->
    <a class="group relative overflow-hidden rounded-2xl bg-card shadow-lg lg:row-span-2" href="<?php the_permalink(); ?>">
        <div class="<?php echo $thumbnail_class; ?>">
            <?php if (has_post_thumbnail()) : ?>
                <?php the_post_thumbnail('reeftoday-large', array('class' => 'h-full w-full object-cover transition-transform duration-500 group-hover:scale-105')); ?>
            <?php else : ?>
                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/clownfish-CCErEGDf.jpg" alt="<?php the_title_attribute(); ?>" class="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105">
            <?php endif; ?>
            <div class="absolute inset-0 bg-gradient-to-t from-reef-deep via-reef-deep/40 to-transparent"></div>
        </div>
        
        <div class="absolute inset-x-0 bottom-0 p-6 md:p-8">
            <div class="mb-3 flex items-center gap-3">
                <?php 
                $categories = get_the_category();
                if (!empty($categories)) :
                ?>
                    <span class="rounded-full bg-accent px-3 py-1 text-xs font-semibold text-accent-foreground">
                        <?php echo esc_html($categories[0]->name); ?>
                    </span>
                <?php endif; ?>
                <span class="flex items-center gap-1.5 text-xs text-primary-foreground/70">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-calendar h-3.5 w-3.5">
                        <path d="M8 2v4"></path>
                        <path d="M16 2v4"></path>
                        <rect width="18" height="18" x="3" y="4" rx="2"></rect>
                        <path d="M3 10h18"></path>
                    </svg>
                    <?php echo get_the_date('F j, Y'); ?>
                </span>
            </div>
            
            <h3 class="font-display text-2xl font-bold text-primary-foreground md:text-3xl">
                <?php the_title(); ?>
            </h3>
            
            <p class="mt-2 text-primary-foreground/80">
                <?php echo wp_trim_words(get_the_excerpt(), 20); ?>
            </p>
        </div>
    </a>
<?php else : ?>
    <?php if ($index == 1) : ?>
        <div class="flex flex-col gap-6">
    <?php endif; ?>
    
    <!-- Small Card -->
    <a class="group flex gap-4 overflow-hidden rounded-xl bg-card p-4 shadow-sm transition-shadow hover:shadow-md" href="<?php the_permalink(); ?>">
        <div class="<?php echo $thumbnail_class; ?>">
            <?php if (has_post_thumbnail()) : ?>
                <?php the_post_thumbnail('thumbnail', array('class' => 'h-full w-full object-cover transition-transform duration-300 group-hover:scale-105')); ?>
            <?php else : ?>
                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/reef-tank-DkvgXldr.jpg" alt="<?php the_title_attribute(); ?>" class="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105">
            <?php endif; ?>
        </div>
        
        <div class="flex flex-col justify-center">
            <div class="mb-1.5 flex items-center gap-2">
                <?php 
                $categories = get_the_category();
                if (!empty($categories)) :
                ?>
                    <span class="text-xs font-semibold text-accent">
                        <?php echo esc_html($categories[0]->name); ?>
                    </span>
                <?php endif; ?>
                <span class="text-xs text-muted-foreground"><?php echo get_the_date('F j, Y'); ?></span>
            </div>
            
            <h3 class="font-display text-lg font-semibold leading-snug text-card-foreground transition-colors group-hover:text-primary">
                <?php the_title(); ?>
            </h3>
        </div>
    </a>
    
    <?php if ($index == 3) : ?>
        </div>
    <?php endif; ?>
<?php endif; ?>
