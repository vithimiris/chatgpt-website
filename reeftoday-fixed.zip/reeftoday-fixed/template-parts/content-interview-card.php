<?php
/**
 * Template part for displaying interview cards
 */
?>

<article class="group overflow-hidden rounded-2xl bg-card shadow-lg transition-all hover:shadow-xl">
    <div class="grid md:grid-cols-5">
        <div class="relative aspect-square overflow-hidden md:col-span-2">
            <?php if (has_post_thumbnail()) : ?>
                <?php the_post_thumbnail('reeftoday-medium', array('class' => 'h-full w-full object-cover transition-transform duration-500 group-hover:scale-105')); ?>
            <?php else : ?>
                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/expert-CQGBlJwN.jpg" alt="<?php the_title_attribute(); ?>" class="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105">
            <?php endif; ?>
        </div>
        
        <div class="flex flex-col justify-center p-6 md:col-span-3 md:p-8">
            <span class="text-xs font-semibold uppercase tracking-wide text-accent">
                <?php esc_html_e('Interview', 'reeftoday'); ?>
            </span>
            
            <h3 class="mt-2 font-display text-2xl font-bold leading-tight text-card-foreground transition-colors group-hover:text-primary">
                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
            </h3>
            
            <p class="mt-3 text-muted-foreground">
                <?php echo wp_trim_words(get_the_excerpt(), 25); ?>
            </p>
            
            <div class="mt-4 flex items-center gap-2 text-sm text-muted-foreground">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-calendar h-4 w-4">
                    <path d="M8 2v4"></path>
                    <path d="M16 2v4"></path>
                    <rect width="18" height="18" x="3" y="4" rx="2"></rect>
                    <path d="M3 10h18"></path>
                </svg>
                <?php echo get_the_date('F j, Y'); ?>
            </div>
        </div>
    </div>
</article>
