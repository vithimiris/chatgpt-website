<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <header class="entry-header mb-8">
        <?php the_title('<h1 class="entry-title text-4xl font-bold mb-4">', '</h1>'); ?>
        <div class="entry-meta text-gray-600">
            <?php reeftoday_posted_on(); ?> <?php reeftoday_posted_by(); ?>
        </div>
    </header>

    <?php if (has_post_thumbnail()) : ?>
        <div class="post-thumbnail mb-8">
            <?php the_post_thumbnail('large', array('class' => 'w-full rounded-lg')); ?>
        </div>
    <?php endif; ?>

    <div class="entry-content prose max-w-none">
        <?php the_content(); ?>
    </div>

    <footer class="entry-footer mt-8 pt-8 border-t">
        <?php reeftoday_entry_footer(); ?>
    </footer>
</article>
