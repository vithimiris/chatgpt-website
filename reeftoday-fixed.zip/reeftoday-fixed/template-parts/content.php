<?php
/**
 * Template part for displaying posts
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class('overflow-hidden rounded-2xl bg-card shadow-sm transition-all hover:shadow-xl'); ?>>
    <?php if (has_post_thumbnail()) : ?>
        <div class="post-thumbnail">
            <a href="<?php the_permalink(); ?>">
                <?php the_post_thumbnail('reeftoday-medium', array('class' => 'w-full h-48 object-cover')); ?>
            </a>
        </div>
    <?php endif; ?>
    
    <div class="p-6">
        <header class="entry-header">
            <?php
            if (is_singular()) :
                the_title('<h1 class="entry-title font-display text-3xl font-bold mb-4">', '</h1>');
            else :
                the_title('<h2 class="entry-title font-display text-xl font-bold mb-3"><a href="' . esc_url(get_permalink()) . '" rel="bookmark">', '</a></h2>');
            endif;
            ?>
        </header>

        <div class="entry-content">
            <?php
            if (is_singular()) :
                the_content();
            else :
                the_excerpt();
            endif;
            ?>
        </div>

        <footer class="entry-footer mt-4 text-sm text-muted-foreground">
            <span class="posted-on"><?php echo get_the_date(); ?></span>
        </footer>
    </div>
</article>
