<?php
/**
 * Template part for displaying review cards
 */

$rating = get_post_meta(get_the_ID(), 'rating', true);
if (empty($rating)) $rating = 0;
$manufacturer = get_post_meta(get_the_ID(), 'manufacturer', true);
?>

<article class="group overflow-hidden rounded-2xl bg-card shadow-sm transition-all hover:shadow-xl">
    <div class="relative aspect-square overflow-hidden">
        <?php if (has_post_thumbnail()) : ?>
            <?php the_post_thumbnail('reeftoday-medium', array('class' => 'h-full w-full object-cover transition-transform duration-500 group-hover:scale-105')); ?>
        <?php else : ?>
            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/reef-equipment-BqR8HMxl.jpg" alt="<?php the_title_attribute(); ?>" class="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105">
        <?php endif; ?>
        
        <?php if ($rating > 0) : ?>
            <div class="absolute top-3 right-3 flex items-center gap-1 rounded-full bg-accent px-3 py-1.5 shadow-lg">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-star h-4 w-4 text-accent-foreground">
                    <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
                </svg>
                <span class="font-bold text-accent-foreground"><?php echo esc_html(number_format($rating, 1)); ?></span>
            </div>
        <?php endif; ?>
    </div>
    
    <div class="p-5">
        <?php if (!empty($manufacturer)) : ?>
            <span class="text-xs font-semibold uppercase tracking-wide text-accent">
                <?php echo esc_html($manufacturer); ?>
            </span>
        <?php endif; ?>
        
        <h3 class="mt-2 font-display text-lg font-semibold leading-snug text-card-foreground transition-colors group-hover:text-primary">
            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
        </h3>
        
        <p class="mt-2 text-sm text-muted-foreground">
            <?php echo wp_trim_words(get_the_excerpt(), 15); ?>
        </p>
    </div>
</article>
