<?php
/**
 * The template for displaying single posts
 */

get_header();
?>

<div id="primary" class="content-area">
    <main id="main" class="site-main">

        <?php
        while (have_posts()) :
            the_post();
            ?>
            
            <article id="post-<?php the_ID(); ?>" <?php post_class('single-post-article'); ?>>
                <div class="container mx-auto px-4 py-12">
                    <div class="max-w-4xl mx-auto">
                        
                        <header class="entry-header mb-8">
                            <?php
                            $categories = get_the_category();
                            if (!empty($categories)) :
                            ?>
                                <div class="mb-4">
                                    <span class="inline-block rounded-full bg-accent px-4 py-1.5 text-sm font-semibold text-accent-foreground">
                                        <?php echo esc_html($categories[0]->name); ?>
                                    </span>
                                </div>
                            <?php endif; ?>
                            
                            <?php the_title('<h1 class="entry-title font-display text-4xl md:text-5xl font-bold mb-4">', '</h1>'); ?>
                            
                            <div class="entry-meta flex items-center gap-4 text-sm text-muted-foreground">
                                <span class="flex items-center gap-2">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="h-4 w-4">
                                        <path d="M8 2v4"></path>
                                        <path d="M16 2v4"></path>
                                        <rect width="18" height="18" x="3" y="4" rx="2"></rect>
                                        <path d="M3 10h18"></path>
                                    </svg>
                                    <?php echo get_the_date(); ?>
                                </span>
                                <span class="flex items-center gap-2">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="h-4 w-4">
                                        <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"></path>
                                        <circle cx="12" cy="7" r="4"></circle>
                                    </svg>
                                    <?php the_author(); ?>
                                </span>
                            </div>
                        </header>

                        <?php if (has_post_thumbnail()) : ?>
                            <div class="post-thumbnail mb-8 rounded-2xl overflow-hidden">
                                <?php the_post_thumbnail('reeftoday-hero', array('class' => 'w-full h-auto')); ?>
                            </div>
                        <?php endif; ?>

                        <div class="entry-content prose prose-lg max-w-none">
                            <?php
                            the_content();

                            wp_link_pages(array(
                                'before' => '<div class="page-links">' . esc_html__('Pages:', 'reeftoday'),
                                'after'  => '</div>',
                            ));
                            ?>
                        </div>

                        <footer class="entry-footer mt-8 pt-8 border-t border-border">
                            <?php
                            $tags_list = get_the_tag_list('', esc_html_x(', ', 'list item separator', 'reeftoday'));
                            if ($tags_list) :
                            ?>
                                <div class="tags-links">
                                    <span class="font-semibold"><?php esc_html_e('Tags:', 'reeftoday'); ?></span>
                                    <?php echo $tags_list; ?>
                                </div>
                            <?php endif; ?>
                        </footer>
                    </div>
                </div>
            </article>

            <?php
            // If comments are open or we have at least one comment, load up the comment template.
            if (comments_open() || get_comments_number()) :
                comments_template();
            endif;

        endwhile; // End of the loop.
        ?>

    </main>
</div>

<?php
get_footer();
