<?php
/**
 * Additional helper functions
 *
 * @package ReefToday
 */

/**
 * Get the default hero background image
 */
function reeftoday_get_default_hero_image() {
    return get_template_directory_uri() . '/assets/images/hero-reef-Cs0JYcOD.jpg';
}

/**
 * Get the default placeholder image for posts
 */
function reeftoday_get_default_post_image() {
    return get_template_directory_uri() . '/assets/images/clownfish-CCErEGDf.jpg';
}

/**
 * Get video embed URL from post meta
 */
function reeftoday_get_video_url($post_id = null) {
    if (!$post_id) {
        $post_id = get_the_ID();
    }
    
    return get_post_meta($post_id, 'video_url', true);
}

/**
 * Check if post is marked as featured
 */
function reeftoday_is_featured_post($post_id = null) {
    if (!$post_id) {
        $post_id = get_the_ID();
    }
    
    $is_featured = get_post_meta($post_id, 'is_featured', true);
    return ($is_featured === '1' || $is_featured === 1);
}

/**
 * Display star rating
 */
function reeftoday_display_star_rating($rating, $max_rating = 5) {
    if (!$rating || $rating <= 0) {
        return '';
    }
    
    $output = '<div class="star-rating flex items-center gap-1">';
    
    for ($i = 1; $i <= $max_rating; $i++) {
        if ($i <= $rating) {
            $output .= '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-accent"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>';
        } else {
            $output .= '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-muted-foreground"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>';
        }
    }
    
    $output .= '</div>';
    
    return $output;
}
