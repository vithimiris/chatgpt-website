/**
 * ReefToday Navigation
 * Handles mobile menu toggle
 */

(function() {
    'use strict';

    document.addEventListener('DOMContentLoaded', function() {
        const menuToggle = document.querySelector('.mobile-menu-toggle');
        const mobileNav = document.getElementById('mobile-navigation');

        if (menuToggle && mobileNav) {
            menuToggle.addEventListener('click', function() {
                const expanded = this.getAttribute('aria-expanded') === 'true' || false;
                this.setAttribute('aria-expanded', !expanded);
                mobileNav.classList.toggle('hidden');
            });
        }

        // Close mobile menu when clicking outside
        document.addEventListener('click', function(event) {
            if (!menuToggle || !mobileNav) return;
            
            const isClickInside = menuToggle.contains(event.target) || mobileNav.contains(event.target);
            
            if (!isClickInside && !mobileNav.classList.contains('hidden')) {
                mobileNav.classList.add('hidden');
                menuToggle.setAttribute('aria-expanded', 'false');
            }
        });
    });
})();
