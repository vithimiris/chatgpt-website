<?php
/**
 * The template for displaying archive pages
 */

get_header();
?>

<div id="primary" class="content-area container mx-auto px-4 py-12">
    <main id="main" class="site-main">

        <?php if (have_posts()) : ?>

            <header class="page-header mb-12">
                <?php
                the_archive_title('<h1 class="page-title font-display text-4xl md:text-5xl font-bold mb-4">', '</h1>');
                the_archive_description('<div class="archive-description text-lg text-muted-foreground">', '</div>');
                ?>
            </header>

            <div class="posts-grid grid gap-8 md:grid-cols-2 lg:grid-cols-3">
                <?php
                while (have_posts()) :
                    the_post();
                    get_template_part('template-parts/content', get_post_type());
                endwhile;
                ?>
            </div>

            <?php
            the_posts_navigation();

        else :

            get_template_part('template-parts/content', 'none');

        endif;
        ?>

    </main>
</div>

<?php
get_sidebar();
get_footer();
