<?php
/**
 * Front Page Template - ReefToday Homepage
 * 
 * Features:
 * - Hero section with featured post
 * - Latest articles grid
 * - Videos section
 * - Reviews section  
 * - Interviews section
 */

get_header();

// Get queries for different sections
$featured_query = reeftoday_get_featured_post();
$latest_query = reeftoday_get_latest_posts(4, 1);
$video_query = reeftoday_get_video_posts(4);
$review_query = reeftoday_get_review_posts(4);
$interview_query = reeftoday_get_interview_posts(2);
?>

<div id="primary" class="content-area">
    <!-- Hero Section with Featured Post -->
    <section class="relative min-h-screen overflow-hidden pt-0">
        <?php if ($featured_query->have_posts()) : $featured_query->the_post(); 
            $hero_bg_image = get_post_meta(get_the_ID(), 'hero_background_image', true);
            
            if (!$hero_bg_image && has_post_thumbnail()) {
                $hero_bg_image = get_the_post_thumbnail_url(get_the_ID(), 'reeftoday-hero');
            }
            
            if (!$hero_bg_image) {
                $hero_bg_image = get_template_directory_uri() . '/assets/images/hero-reef-Cs0JYcOD.jpg';
            }
        ?>
            <div class="absolute inset-0">
                <img src="<?php echo esc_url($hero_bg_image); ?>" alt="<?php echo esc_attr(get_the_title()); ?>" class="h-full w-full object-cover">
                <div class="absolute inset-0 bg-gradient-to-t from-reef-deep via-reef-deep/60 to-transparent"></div>
                <div class="absolute inset-0 bg-gradient-to-r from-reef-deep/80 via-transparent to-transparent"></div>
            </div>
            
            <div class="container relative z-10 flex min-h-screen flex-col justify-end pb-16 pt-32 md:pb-24">
                <div class="max-w-3xl animate-fade-in">
                    <div class="mb-4 flex items-center gap-3">
                        <span class="rounded-full bg-accent px-4 py-1.5 text-sm font-semibold text-accent-foreground"><?php esc_html_e('Featured', 'reeftoday'); ?></span>
                        <span class="flex items-center gap-2 text-sm text-primary-foreground/80">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-calendar h-4 w-4">
                                <path d="M8 2v4"></path>
                                <path d="M16 2v4"></path>
                                <rect width="18" height="18" x="3" y="4" rx="2"></rect>
                                <path d="M3 10h18"></path>
                            </svg>
                            <?php echo get_the_date('F j, Y'); ?>
                        </span>
                    </div>
                    
                    <h1 class="font-display text-4xl font-bold leading-tight text-primary-foreground md:text-5xl lg:text-6xl">
                        <?php the_title(); ?>
                    </h1>
                    
                    <p class="mt-4 text-lg text-primary-foreground/80 md:text-xl">
                        <?php echo wp_trim_words(get_the_excerpt(), 30); ?>
                    </p>
                    
                    <div class="mt-8 flex flex-wrap items-center gap-4">
                        <a href="<?php the_permalink(); ?>" class="group flex items-center gap-2 rounded-full bg-primary px-6 py-3 font-semibold text-primary-foreground transition-all hover:bg-reef-lagoon">
                            <?php esc_html_e('Read Full Story', 'reeftoday'); ?>
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-arrow-right h-4 w-4 transition-transform group-hover:translate-x-1">
                                <path d="M5 12h14"></path>
                                <path d="m12 5 7 7-7 7"></path>
                            </svg>
                        </a>
                    </div>
                </div>
            </div>
            <?php wp_reset_postdata(); ?>
        <?php endif; ?>
        
        <div class="absolute bottom-0 left-0 right-0">
            <svg viewBox="0 0 1440 80" fill="none" xmlns="http://www.w3.org/2000/svg" class="w-full">
                <path d="M0 80H1440V40C1440 40 1320 0 1080 20C840 40 600 80 360 60C120 40 0 40 0 40V80Z" fill="hsl(var(--background))"></path>
            </svg>
        </div>
    </section>

    <!-- Latest Stories Section -->
    <section class="bg-background py-16 md:py-24">
        <div class="container">
            <div class="mb-10 flex items-end justify-between">
                <div>
                    <span class="text-sm font-semibold uppercase tracking-wider text-accent"><?php esc_html_e('Latest Updates', 'reeftoday'); ?></span>
                    <h2 class="mt-2 font-display text-3xl font-bold text-foreground md:text-4xl"><?php esc_html_e("Today's Top Stories", 'reeftoday'); ?></h2>
                </div>
                <a class="group hidden items-center gap-2 text-sm font-semibold text-primary transition-colors hover:text-reef-lagoon sm:flex" href="<?php echo esc_url(get_permalink(get_option('page_for_posts'))); ?>">
                    <?php esc_html_e('View All News', 'reeftoday'); ?>
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-arrow-right h-4 w-4 transition-transform group-hover:translate-x-1">
                        <path d="M5 12h14"></path>
                        <path d="m12 5 7 7-7 7"></path>
                    </svg>
                </a>
            </div>

            <?php if ($latest_query->have_posts()) : ?>
                <div class="grid gap-6 lg:grid-cols-2">
                    <?php 
                    $post_index = 0;
                    while ($latest_query->have_posts()) : $latest_query->the_post(); 
                        get_template_part('template-parts/content', 'post-card', array('index' => $post_index));
                        $post_index++;
                    endwhile; 
                    wp_reset_postdata();
                    ?>
                </div>
            <?php else : ?>
                <div class="text-center py-12">
                    <p class="text-muted-foreground"><?php esc_html_e('No posts found. Create your first post to see it here!', 'reeftoday'); ?></p>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- Videos Section -->
    <section class="bg-secondary py-16 md:py-24">
        <div class="container">
            <div class="mb-10 text-center">
                <span class="text-sm font-semibold uppercase tracking-wider text-accent"><?php esc_html_e('Featured Videos', 'reeftoday'); ?></span>
                <h2 class="mt-2 font-display text-3xl font-bold text-foreground md:text-4xl"><?php esc_html_e('Watch & Learn', 'reeftoday'); ?></h2>
                <p class="mx-auto mt-3 max-w-2xl text-muted-foreground"><?php esc_html_e("Expert tutorials, tank tours, and behind-the-scenes looks at the world's most impressive reef systems.", 'reeftoday'); ?></p>
            </div>
            
            <div class="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
                <?php 
                if ($video_query->have_posts()) :
                    while ($video_query->have_posts()) : $video_query->the_post(); 
                        get_template_part('template-parts/content', 'video-card');
                    endwhile;
                    wp_reset_postdata();
                endif;
                ?>
            </div>
        </div>
    </section>

    <!-- Reviews Section -->
    <section class="bg-background py-16 md:py-24">
        <div class="container">
            <div class="mb-10 flex items-end justify-between">
                <div>
                    <span class="text-sm font-semibold uppercase tracking-wider text-accent"><?php esc_html_e('Equipment Reviews', 'reeftoday'); ?></span>
                    <h2 class="mt-2 font-display text-3xl font-bold text-foreground md:text-4xl"><?php esc_html_e('Honest Reviews, Real Results', 'reeftoday'); ?></h2>
                </div>
            </div>
            
            <div class="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
                <?php 
                if ($review_query->have_posts()) :
                    while ($review_query->have_posts()) : $review_query->the_post();
                        get_template_part('template-parts/content', 'review-card');
                    endwhile;
                    wp_reset_postdata();
                endif;
                ?>
            </div>
        </div>
    </section>

    <!-- Interviews Section -->
    <section class="bg-secondary py-16 md:py-24">
        <div class="container">
            <div class="mb-10 text-center">
                <span class="text-sm font-semibold uppercase tracking-wider text-accent"><?php esc_html_e('Expert Interviews', 'reeftoday'); ?></span>
                <h2 class="mt-2 font-display text-3xl font-bold text-foreground md:text-4xl"><?php esc_html_e('Learn from the Pros', 'reeftoday'); ?></h2>
            </div>
            
            <div class="grid gap-8 lg:grid-cols-2">
                <?php 
                if ($interview_query->have_posts()) :
                    while ($interview_query->have_posts()) : $interview_query->the_post();
                        get_template_part('template-parts/content', 'interview-card');
                    endwhile;
                    wp_reset_postdata();
                endif;
                ?>
            </div>
        </div>
    </section>
</div>

<?php
get_footer();
